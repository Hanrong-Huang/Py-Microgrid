locations = (
    (39.91, -105.22, 1800.0),   # flatirons campus
    (36.334, -119.769, 70.0),     # high correlation
    (33.209, -108.283, 2000.0),      # low correlation
    (34.084, -114.851, 1600.0), # Rice, CA
    )

# (36.334, -119.769, 68.0),     # high correlation
# (33.209, -108.283)      # low correlation

loc = 1
lat = locations[loc][0]
lon = locations[loc][1]
